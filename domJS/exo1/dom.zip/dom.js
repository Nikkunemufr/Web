"use strict";

if (document.body === null) {
	alert("Le DOM n'est pas construit !");
} else {
	alert("Le DOM est construit");
}
